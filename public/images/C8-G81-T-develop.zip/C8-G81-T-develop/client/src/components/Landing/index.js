export { default as Hero } from "./LandingHero";
export { default as AboutUs } from "./AboutUs";
export { default as Features } from "./Features";
export { default as Contat } from "./Contact";
